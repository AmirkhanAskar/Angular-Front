import { Component, OnInit } from '@angular/core';
import {CategoriesService} from '../categories.service';
import {User} from '../User';
import {Location} from '@angular/common';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registered: boolean;
  constructor(private categoryService: CategoriesService, private location: Location) {
  }

  ngOnInit(): void {
  }

}
