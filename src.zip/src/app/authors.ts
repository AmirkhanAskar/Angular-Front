export interface Authors{
  id: number;
  name: string;
  biography: string;
  image: string;
}
